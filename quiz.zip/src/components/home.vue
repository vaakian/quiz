<template>
    <div id="home">
        <quizbody></quizbody>
        <!-- <van-button></van-button> -->
        
    </div>
</template>
<script>
import quizbody from './quizbody'
// import navBar from './navBar'
export default {
    name: 'home',
    components: {
        // navBar:navBar
        quizbody: quizbody
    },
    created: function(){
        this.$emit("updataTitle",0)
    }
}
</script>

