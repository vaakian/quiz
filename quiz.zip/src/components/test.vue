<template>
    <div>
        asdasd
        阿瑟东阿瑟东asd
        <a href="阿三打算"></a>
        {{ testmsg }}
    </div>
</template>
<script>
export default {
    props: ['testmsg']
}
</script>
