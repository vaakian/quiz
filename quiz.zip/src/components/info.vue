<template>
    <div>
        待完善……~
        <h2>临时访问：</h2>
        <a href="//132.232.7.38/old/2018bk.php"><button class="myBtn">2018本科</button></a>
        <br>
        <a href="//132.232.7.38/old/2018zk.php"><button class="myBtn">2018专科</button></a>
    </div>
</template>
<script>
export default {
    activated: function() {
        this.$emit("updataTitle",2)
    }
}
</script>

